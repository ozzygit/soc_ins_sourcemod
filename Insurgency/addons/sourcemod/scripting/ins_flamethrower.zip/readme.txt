weapon_flame is the weapon that fires the flamethrower so you need to add that entry to your weapons in your theater file

I included the source vpk for the cheesy flamethrower model I am using.  It is on the workshop as well if you want to use it.  https://steamcommunity.com/sharedfiles/filedetails/?id=1889768658

Once the theater is set up and the model is subscribed you will have to determine the id for the weapon_flame. Go in game and select the flamethrower and fire it... you will see the id in the chat messages.  Make sure it is 14.  If not you will need to change:  convar_MissileID = CreateConVar("sm_flame_missileid", "14") in the plugin and recompile.  (sorry I never set up the autoexec to write cfg file)